
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                
                 <div class="card-header pb-3 pt-3 text-uppercase">
                    	Book Visit</div>
                

                <div class="card-body">
                <form class="reportform padd15" action="" method="get" name="inquiry" autocomplete="off">
                            <div class="row p-0">
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                    <select class="select2 size-1 form-control wide mb-3" id="vendors" name="vendors" >
                                        <option value="">Select Vendor</option>
                                        <?php if(!empty($vendors_info)): ?>
                                            <?php $__currentLoopData = $vendors_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($vendors == $d->id): ?>
                                                    <option value="<?php echo e($d->id); ?>" selected="selected"><?php echo e($d->company_name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($d->id); ?>" ><?php echo e($d->company_name); ?></option>
                                                <?php endif; ?>  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    
                                    <div class="form-group">
                                    <input type="search" name="inquiry_name"  value="<?php echo e($inquiry_name); ?>" id="inquiry_name" placeholder="search" class=" form-control" >
                                </div>
                                </div>

                                <div class="col-md-2">
                                    
                                    <div class="form-group">
                                    <?php if(isset($start_date) && isset($start_date)!=''): ?>
                                        <input id="datetimepicker6" style="" name="from" type="text" class="form-control dt1" data-date-format="YYYY-MM-DD" value="<?php echo e($from); ?>" placeholder="Start date"/>
                                    <?php else: ?>
                                        <input id="datetimepicker6" style="" name="from" type="text" class="form-control dt1" data-date-format="YYYY-MM-DD" value="" placeholder="Start date"/>
                                    <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                 
                                    <div class="form-group">
                                    <?php if(isset($end_date) && isset($end_date)!=''): ?>
                                 
                                    <input id="datetimepicker7" name="to" type="text" class="form-control dt1" data-date-format="YYYY-MM-DD" value="<?php echo e($to); ?>"  placeholder="End date"/>
                                    <?php else: ?>
                                    <input id="datetimepicker7" name="to" type="text" class="form-control dt1" data-date-format="YYYY-MM-DD" value=""  placeholder="End date"/>
                                    <?php endif; ?>
                                    </div>
                                </div>

<div class="col-md-3">
                            	<input type="submit" class="btn btn-primary text-uppercase" value="Submit">
                                
                            	
                                 <a href="<?php echo e(url('/admin/bookvisit')); ?>" data-toggle="tooltip" title="Reset"><input type="button" class="btn btn-light text-uppercase" value="Reset"></a>
                            </div>	
                                  </div>
                        </form>
                    <div class="table-responsive">
                        <table class="table table-responsive-md table-bordered">
                            <thead>
                                <tr>
                                    <th>Vendor Name</th>
                                    <th>Property Name</th>
                                    <th>User Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Booking Date</th>
                                    <th>Timing</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php // echo "<pre>"; print_r($product); exit; ?>
                                <?php if(count($bookvisit)): ?>
                                    <?php $__currentLoopData = $bookvisit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="tr_<?php echo e($bv->id); ?>">
                                        <td><?php echo e($bv->company_name); ?></td> 
                                        <td><?php echo e($bv->project_name); ?></td> 
                                        <td><?php echo e($bv->name); ?></td> 
                                        <td><?php echo e($bv->email); ?></td> 
                                        <td><?php echo e($bv->contact); ?></td> 
                                        <td><?php echo e(date("d/M/Y", strtotime($bv->book_date))); ?></td> 
                                        <td><?php echo e(date("h:i A", strtotime($bv->book_from_time))); ?> - <?php echo e(date("h:i A", strtotime($bv->book_to_time))); ?></td> 
                                        <td>
                                            
                                            <a href="#" data-toggle="modal" data-target="#bookvisit_delete_confirm"  data-id="<?php echo e($bv->id); ?>" class="onclick btn btn-danger shadow btn-xs sharp"><i class="fas fa-trash-alt"></i></a>
                                        </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                <td colspan="9">No result found</td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($bookvisit->links()); ?>

                    </div>
                </div>
            
        </div>
    </div>

        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Remove Item</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this item?</p>
                </div>
                <input type="hidden" name="id" id="id" value="">
                <div class="modal-footer">
                	<button type="button" id="close" class="btn btn-light close text-uppercase">Cancel</button>
                    <button type="button" id="btn_ok_1" class="btn btn-primary text-uppercase">Sure</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
<script type="text/javascript">
    jQuery(document).ready(function () {
        
        $(".select2").select2();

        jQuery('#datetimepicker6').datepicker({ dateFormat: 'yy-mm-dd' });
        jQuery('#datetimepicker7').datepicker({ dateFormat: 'yy-mm-dd' });


        $(document).on("click", ".close", function () {
            $('#myModal').modal('hide');
        });

        $(document).on("click", ".onclick", function () {
            var id = $(this).data('id');
            $(".modal-dialog #id").val( id );
            $('#myModal').modal('show');
        });

        jQuery("#btn_ok_1").on('click',function(){
            var token = $('meta[name="csrf_token"]').attr('content');
            var id = jQuery("#id").val();
            $.ajax({
                type:'POST',
                url:'/admin/bookvisit/delete/'+id,
                data:{_token: token},
                success:function(data){
                    if (data == 'success') {
                        $( ".close" ).trigger( "click" );
                        $("#tr_"+id).css('display','none');
                        window.location.reload();
                    }
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/admin/bookvisit/index.blade.php ENDPATH**/ ?>