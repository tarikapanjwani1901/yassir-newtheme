
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row p-0">
           <?php if(session('success')): ?>
           <div class="col-lg-12">
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="col-lg-12">
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

                </div>
            </div>
        <?php endif; ?>

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header pb-3 pt-3 text-uppercase">
                    	CMS
                         
                        </div>
                        

                    <div class="card-body ">
                             
                        <div class="table-responsive mt-3">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th class="ac">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($cms)): ?>
                                        <?php foreach ($cms as $key => $value) { ?>
                                            <tr id="tr_<?php echo e($value->id); ?>">
                                                <td><?php echo $value->title; ?></td>
                                                <td  align="center">
                                                        <a href="cms/edit/<?php echo e($value->id); ?>" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a>
                                                        <a href="../<?php echo e($value->link); ?>" target="_blank" class="btn btn-warning shadow btn-xs sharp"><i class="fas fa-eye"></i></a>
                                                   
                                                </td>

                                            </tr>
                                        <?php } ?>
                                    <?php else: ?>
                                    <tr> 
                                        <td colspan="2">No records found</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo e($cms->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/admin/cms/index.blade.php ENDPATH**/ ?>