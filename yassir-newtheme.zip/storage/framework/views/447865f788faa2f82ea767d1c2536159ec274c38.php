
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vendor.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/vendor/dashboard.blade.php ENDPATH**/ ?>