
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row  p-0">
            <div class="col-lg-12">
                <div class="card">
                	<div class="card-header pb-3 pt-3 text-uppercase">
                    	Edit Advertisement
                    </div>

                    <div class="card-body">
                        <form method="post" id="add_advertise" enctype="multipart/form-data" method="post" files="true" action="<?php echo e(route('admin.advertise.update',[$advertise->id])); ?>">
                            <div class="row p-0">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Select Vendor<span class="required_field">*</span> </label>    
                                        <select name="vendor_id" id="vendor_id" class="select2 form-control required">
                                            <option value="">Select Vendor</option>
                                            <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($advertise->vendor_id == $v->id): ?>
                                                    <option value="<?php echo e($v->id); ?>" selected="selected"><?php echo e($v->company_name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($v->id); ?>"><?php echo e($v->company_name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div> 	
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                    <label class="control-label">Title<span class="required_field">*</span> </label>    
                                    <input id="title" name="title" type="text" value="<?php echo e($advertise->title); ?>"  class="form-control required"  autocomplete="off">
                                    </div> 	
                                </div>
                                     
                                    <div class="col-md-12">
                                   		<div class="form-group">
                                         <label class="control-label" style="vertical-align:top;">Image<span class="required_field">*</span> </label>    
                               			<div class="fileinput <?php echo (!empty($advertise->file_name))?"fileinput-exists":"fileinput-new" ?> " data-provides="fileinput">
                                        
                                            <div>
                                        <span class="btn btn-default btn-file">
                                            <span class="fileinput-new btn btn-primary text-uppercase">Select image</span>
                                            <?php if($advertise->file_name): ?>
                                          	  <input id="inputFile" accept="image/*" name="image" type="file" class="form-control"/>
                                          
                                            <?php else: ?>
                                            <input id="inputFile" accept="image/*" name="image" type="file" class="form-control requiresd"/>
                                            <?php endif; ?>
                                        </span>
                                        <div class="fileinput-preview thumbnail" style="max-width: 200px; max-height: 200px;">
                                           	  <?php if($advertise->file_name): ?>
                                                        <?php if((substr($advertise->file_name, 0,5)) == 'https'): ?>
                                                            <img src="<?php echo e($advertise->file_name); ?>" alt="img" class="img-responsive"/>
                                                        <?php else: ?>
                                                            <img src="<?php echo url('/').'/images/advertise/'.$advertise->id .'/'. $advertise->file_name; ?>" alt="img" class="img-responsive"/>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                           </div>
                                        <br />
                                        <?php if(!empty($advertise->file_name)): ?>
                                        <a href="#" style="margin-left:90px;" class="btn btn-danger fileinput-exists mb-1 btn btn-danger text-uppercase" data-dismiss="fileinput">Remove</a>
                                         <?php else: ?>
                                        <a href="#" style="margin-left:90px;" class="btn btn-danger fileinput-exists mb-1 btn btn-danger text-uppercase" data-dismiss="fileinput">Remove</a>
                                        
                                         <?php endif; ?> 
                                            </div>
                                      	   
                                            
                                        </div>
                                       
                                    </div> 	
                                    </div> 	
                                
                                		
                                </div>
                                <div class="form-group text-center">
                                    <div class=" text-right">
                                        <input type="submit" class="btn btn-primary text-uppercase" value="Submit" name="submit">
                                        <a href="<?php echo e(url('/admin/advertise')); ?>"  data-toggle="tooltip" title="Cancel"><input type="button" class="btn btn-danger text-uppercase" value="Cancel"></a>
                                    </div>
                                </div>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
    <script type="text/javascript">
        jQuery(document).ready(function () {

            $(".select2").select2();

            jQuery(document).on("click",".adv_image",function(e){
                $("#image").addClass('required');
            });

            jQuery(document).on("submit","#add_advertise",function(e){
                if($('#add_advertise').valid()){
                    $('#add_advertise').submit();
                    return true;	
                }else{
                    return false;		
                }	
		    });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/admin/advertise/edit.blade.php ENDPATH**/ ?>