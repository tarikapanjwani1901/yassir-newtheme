
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      
        <div class="row  p-0">
        	            <?php if(session('success')): ?>
           <div class="col-lg-12">
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="col-lg-12">
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

                </div>
            </div>
        <?php endif; ?>

            <div class="col-lg-12">
                <div class="card">
                	<div class="card-header pb-3 pt-3 text-uppercase">
                    	Add Blog Tag
                        </div>
                       
                    <div class="card-body">
                        <form method="post" id="form" enctype="multipart/form-data">
                             	<div class="row p-0">
                                	
                                	<div class="col-md-12">
                                   		<div class="form-group">
                                         <label class="control-label">Tag Name<span class="required_field">*</span> </label>    
                                         <input id="title" name="title" type="text" class="form-control required" autocomplete="off" >
                                    </div> 	
                                    </div>
                                    	
                                </div>
                              <div class="form-group text-center">
                                    <div class=" text-right">
                                        <input type="submit" class="btn btn-primary text-uppercase" value="Submit" name="submit">
                                        <a href="<?php echo e(url('/admin/blog_tag')); ?>"  data-toggle="tooltip" title="Cancel"><input type="button" class="btn btn-danger text-uppercase" value="Cancel"></a>
                                    </div>
                                </div>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery(".select2").select2();
		jQuery(document).on("submit","#form",function(e){
			
			if($('#form').valid()){
				$('#form').submit();
				return true;	
			}else{
				return false;		
			}	
		});
       
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/admin/blogs/tag/add.blade.php ENDPATH**/ ?>