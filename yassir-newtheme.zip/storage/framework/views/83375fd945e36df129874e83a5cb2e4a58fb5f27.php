<!--**********************************
    Footer start
***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Silverxis</a> <?php echo e(date('Y')); ?></p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************--><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>