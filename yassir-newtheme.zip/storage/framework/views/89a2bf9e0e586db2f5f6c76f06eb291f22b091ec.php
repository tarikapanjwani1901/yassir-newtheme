
<?php $__env->startSection('content'); ?>
<style>
.select2-search.select2-search--inline {
	display: none;
}
.select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
	border: 0;
	background: #ccc;
	border-radius: 6px;
	padding: 1px 6px;
}
</style>
    <div class="container-fluid">
      
        <div class="row  p-0">
         <?php if(session('success')): ?>
           <div class="col-lg-12">
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="col-lg-12">
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

                </div>
            </div>
        <?php endif; ?>

            <div class="col-lg-12">
                <div class="card">
                	<div class="card-header pb-3 pt-3 text-uppercase">
                    	Edit Blog
                        </div>
                    <div class="card-body">
                    <form method="post" id="form" enctype="multipart/form-data">
                      <input type="hidden" name="id" value="<?php echo e($blog->id); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                       <div class="row p-0">
                                	<div class="col-md-9">
                                   		<div class="form-group">
                                         <label class="control-label">Title<span class="required_field">*</span> </label>    
                                          <input id="title" name="title" value="<?php echo e($blog->title); ?>" type="text" class="form-control required"  autocomplete="off">
                                    </div> 	
                                    </div>
                                    <div class="col-md-3">
                                   		<div class="form-group">
                                         <label class="control-label">Status<span class="required_field">*</span> </label>    
                                     	       <?php echo Form::select('status', $status, $blog->status,['class' => 'select2 form-control required']); ?>

                                    </div> 	
                                    </div>
                                    <div class="col-md-6">
                                   		<div class="form-group">
                                         <label class="control-label">Category</label>    
                                         <select name="category[]" multiple="multiple" class="form-control select2">
                                         	<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleKey=>$single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            	<?php if(in_array($singleKey,$categoryAssingList)): ?>
                                                <option value="<?php echo e($singleKey); ?>" selected="selected"><?php echo e($single); ?></option>
                                                <?php else: ?>
                                                
                                                <option value="<?php echo e($singleKey); ?>"><?php echo e($single); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                               
                                   
                                    </div> 	
                                    </div>
                                	<div class="col-md-6">
                                   		<div class="form-group">
                                         <label class="control-label">Tag</label>    
                                       
                                         <select name="tag[]" multiple="multiple" class="form-control select2">
                                         	<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleKey=>$single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            	<?php if(in_array($singleKey,$tagAssingList)): ?>
                                                <option value="<?php echo e($singleKey); ?>" selected="selected"><?php echo e($single); ?></option>
                                                <?php else: ?>
                                                
                                                <option value="<?php echo e($singleKey); ?>"><?php echo e($single); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                               
                               
                                    </div> 	
                                    </div>
                                    
                                    
                                    
                                    <div class="col-md-12">
                                   		<div class="form-group">
                                         <label class="control-label">Description</label>    
                                         
                                            <textarea rows='10' name="description" id="description" class='textarea form-control' style="width: 100%; height: 900px !important; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e($blog->content); ?></textarea
                                        
                                    >
                                         </div>
                               
                                    </div> 	
                                    <div class="col-md-12">
                                   		<div class="form-group">
                                         <label class="control-label" style="vertical-align:top;">Image<span class="required_field">*</span> </label>    
                               			<div class="fileinput <?php echo (!empty($blog->image))?"fileinput-exists":"fileinput-new" ?> " data-provides="fileinput">
                                        
                                            <div>
                                        <span class="btn btn-default btn-file">
                                            <span class="fileinput-new btn btn-primary text-uppercase">Select image</span>
                                            <?php if($blog->image): ?>
                                          	  <input id="inputFile" accept="image/*" name="inputFile" type="file" class="form-control"/>
                                          
                                            <?php else: ?>
                                            <input id="inputFile" accept="image/*" name="inputFile" type="file" class="form-control requiresd"/>
                                            <?php endif; ?>
                                        </span>
                                        <div class="fileinput-preview thumbnail" style="max-width: 200px; max-height: 200px;">
                                           	  <?php if($blog->image): ?>
                                                        <?php if((substr($blog->image, 0,5)) == 'https'): ?>
                                                            <img src="<?php echo e($blog->image); ?>" alt="img" class="img-responsive"/>
                                                        <?php else: ?>
                                                            <img src="<?php echo url('/').'/images/blog/'.$blog->id .'/'. $blog->image; ?>" alt="img" class="img-responsive"/>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                           </div>
                                        <br />
                                        <?php if(!empty($blog->image)): ?>
                                        <a href="#" style="margin-left:90px;" class="btn btn-danger fileinput-exists mb-1 btn btn-danger text-uppercase" data-dismiss="fileinput">Remove</a>
                                         <?php else: ?>
                                        <a href="#" style="margin-left:90px;" class="btn btn-danger fileinput-exists mb-1 btn btn-danger text-uppercase" data-dismiss="fileinput">Remove</a>
                                        
                                         <?php endif; ?> 
                                            </div>
                                      	   
                                            
                                        </div>
                                       
                                    </div> 	
                                    </div>
                                		
                                </div>
                              <div class="form-group text-center">
                                    <div class=" text-right">
                                        <input type="submit" class="btn btn-primary text-uppercase" value="Submit" name="submit">
                                        <a href="<?php echo e(url('/admin/blog')); ?>"  data-toggle="tooltip" title="Cancel"><input type="button" class="btn btn-danger text-uppercase" value="Cancel"></a>
                                    </div>
                                </div>

                        
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
<script type="text/javascript">
jQuery(document).ready(function () {
	 jQuery('.textarea').summernote({
			   codemirror: { // codemirror options
    theme: 'monokai'
  },
        placeholder: 'write content here...',
        fontNames: ['Lato', 'Arial', 'Courier New'],

    });
  	$(".select2").select2();
        jQuery(document).on("submit","#form",function(e){
			
			if($('#form').valid()){
				$('#form').submit();
				return true;	
			}else{
				return false;		
			}	
		});
    
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/admin/blogs/blog/edit.blade.php ENDPATH**/ ?>