<?php if(session('user_role')=='admin'): ?>
    <?php echo $__env->make('errors.admin403', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(session('user_role')=='vendor'): ?>
    <?php echo $__env->make('errors.vendor403', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('errors.teacher403', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?> 
<?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/errors/403.blade.php ENDPATH**/ ?>