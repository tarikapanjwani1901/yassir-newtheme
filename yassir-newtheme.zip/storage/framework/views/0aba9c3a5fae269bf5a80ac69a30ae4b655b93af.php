
<?php $__env->startSection('content'); ?>
    <div class="col-lg-10 col-md-10 admin-background permission-msg">
        <h1>You don't have permission</h1>   
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.vendor.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/errors/vendor403.blade.php ENDPATH**/ ?>