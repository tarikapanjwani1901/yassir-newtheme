
<?php $__env->startSection('content'); ?>
<h2>Hello !</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.marketing.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/marketing/dashboard.blade.php ENDPATH**/ ?>