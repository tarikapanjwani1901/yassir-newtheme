
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="page-titles">
            <a href="javascript:void(0)">Inquiry List</a>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <form class="reportform padd15" action="" method="get" name="inquiry" autocomplete="off">
                            <div class="row">
                                
                                <div class="col-md-3">
                                    <select class="default-select size-1 form-control wide mb-3" id="vendors" name="vendors" >
                                        <option value="">Select Vendor</option>
                                        <?php if(!empty($vendors_info)): ?>
                                            <?php $__currentLoopData = $vendors_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($vendors == $d->vl_id): ?>
                                                <option value="<?php echo e($d->vl_id); ?>" selected="selected"><?php echo e($d->l_title); ?></option>
                                                <?php else: ?>
                                                <option value="<?php echo e($d->vl_id); ?>" ><?php echo e($d->l_title); ?></option>
                                                <?php endif; ?>  
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <input type="search" name="inquiry_name" id="inquiry_name" placeholder="search" class=" form-control" >
                                </div>

                                <div class="col-md-2">
                                    <input id="datetimepicker6" style="" name="from" type="text" class="form-control dt1" data-date-format="YYYY-MM-DD" value="" placeholder="Start date"/>
                                </div>

                                <div class="col-md-2">
                                    <input id="datetimepicker7" name="to" type="text" class="form-control dt1" data-date-format="YYYY-MM-DD" value="" placeholder="End date"/>
                                </div>

                                <div class="col-md-1">
                                    <input type="submit" class="btn btn-primary" value="Submit" id="submit">
                                </div>

                                <div class="col-md-1">
                                    <a href="<?php echo e(url('/')); ?>/admin/inquiry" data-toggle="tooltip" title="" data-original-title="Reset" class="btn btn-primary exporting"><i class="fa fa-refresh" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </form>    

                    </div>
                

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-responsive-md table-bordered">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Property Name</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Info</th>
                                    <th>Date & Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = ($inquires->currentpage()-1)*$inquires->perpage() + 1 ?>
                                <?php if(count($inquires)): ?>
                                    <?php $__currentLoopData = $inquires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="tr_<?php echo e($inquire->id); ?>">
                                            <td> <?php echo e($i++); ?></td>
                                            <td> <?php echo e(ucfirst($inquire->l_title)); ?> </td>
                                            <td> <?php echo e(ucfirst($inquire->name)); ?> </td>
                                            <td> <?php echo e(ucfirst($inquire->email)); ?> </td>
                                            <td> <?php echo e($inquire->contact); ?> </td>
                                            <td> <?php echo e($inquire->message); ?> </td>
                                            <td> <?php echo date('M j h:ia', strtotime($inquire->created_at)) ?> </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <td colspan="7">No Result Found</td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($inquires->links()); ?>

                    </div>
                </div>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
    $(function () {
        $('#datetimepicker6').datetimepicker();
        $('#datetimepicker7').datetimepicker();
    });
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\yassir-newtheme\resources\views/admin/inquiry/index.blade.php ENDPATH**/ ?>