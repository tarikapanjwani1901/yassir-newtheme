
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      
        <div class="row  p-0">
            <?php if(session('success')): ?>
           <div class="col-lg-12">
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="col-lg-12">
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

                </div>
            </div>
        <?php endif; ?>

            <div class="col-lg-12">
                <div class="card">
                	<div class="card-header pb-3 pt-3 text-uppercase">
                    	Edit User
                        </div>
                       
                    <div class="card-body">
                        <form method="post" id="adduser" enctype="multipart/form-data">
                             	<div class="row p-0">
                                	<div class="col-md-2">
                                   		<div class="form-group">
                                         <label class="control-label">Status<span class="required_field">*</span> </label>    
                                     	       <?php echo Form::select('status', $status, $u->status,['class' => 'select2 form-control required']); ?>

                                    </div> 	
                                    </div>
                                    <div class="col-md-2">
                                   		<div class="form-group">
                                         <label class="control-label">User Role<span class="required_field">*</span> </label>    
                                     	       <?php echo Form::select('user_role', $user_role, $u->user_role,['class' => 'select2 form-control required']); ?>

                                    </div> 	
                                    </div>
                                    <div class="col-md-4">
                                   		<div class="form-group">
                                         <label class="control-label">User Name<span class="required_field">*</span> </label>    
                                     	 <input type="text" placeholder="User Name" value="<?php echo e($u->user_name); ?>" name="user_name" class="form-control required" />
                                    </div> 	
                                    </div>
                                    <div class="col-md-4">
                                   		<div class="form-group">
                                         <label class="control-label">First Name<span class="required_field">*</span> </label>    
                                     	 <input type="text" placeholder="First Name" value="<?php echo e($u->first_name); ?>" name="first_name" class="form-control required" />
                                    </div> 	
                                    </div>
                                	<div class="col-md-3">
                                   		<div class="form-group">
                                         <label class="control-label">Last Name<span class="required_field">*</span> </label>    
                                         <input type="text" placeholder="Last Name" value="<?php echo e($u->last_name); ?>" name="last_name" class="form-control required" />
                                    </div> 	
                                    </div>
                                    	
                                	<div class="col-md-3">
                                   		<div class="form-group">
                                         <label class="control-label">Email<span class="required_field">*</span> </label>    
                                         <input type="text" placeholder="Email" value="<?php echo e($u->email); ?>" name="email" class="form-control email required" />
                                    </div> 	
                                    </div>
                                	
                                    
                                	<div class="col-md-3">
                                   		<div class="form-group">
                                         <label class="control-label">Mobile Number<span class="required_field">*</span> </label>    
                                     	 <input type="text" placeholder="Mobile Number" min="10" value="<?php echo e($u->mobile); ?>" name="mobile" class="form-control number required" />
                                    </div> 	
                                    </div>
                                	<div class="col-md-3">
                                   		<div class="form-group">
                                         <label class="control-label">Company Name<span class="required_field">*</span> </label>    
                                         <input type="text" placeholder="Company Name" value="<?php echo e($u->company_name); ?>" name="company_name" class="form-control required" />
                                    </div> 	
                                    </div>
                                    <div class="col-md-4">
                                   		<div class="form-group">
                                         <label class="control-label">GST Number<span class="required_field">*</span> </label>    
                                         <input type="text" placeholder="GST Number" value="<?php echo e($u->gst_number); ?>" name="gst_number" class="form-control required" />
                                    </div> 	
                                    </div>
                                    <div class="col-md-4">
                                   		<div class="form-group">
                                         <label class="control-label">Date of Birth<span class="required_field">*</span> </label>    
                                     	 <input type="text" placeholder="Date Of Birth" value="<?php echo e($u->dob); ?>" name="dob" class="form-control datepicker required" />
                                    </div> 	
                                    </div>
                                	
                                    <div class="col-md-4">
                                   		<div class="form-group">
                                         <label class="control-label">Gender<span class="required_field">*</span> </label>    
                                          <?php echo Form::select('gender', $gender, $u->gender,['class' => 'select2 form-control required']); ?>

                                    </div> 	
                                    </div>	
                                </div>
                                
                                
                                
                                <div class="row p-0">
                                	
                                    <div class="col-md-12">
                                   		<div class="form-group">
                                         <label class="control-label">Bio (brief intro)<span class="required_field">*</span> </label>    
                                        <textarea style="resize:none;" name="bio" class="form-control"><?php echo e($u->bio); ?></textarea>
                                    </div> 	
                                    </div>
                                    
                                    <div class="col-md-12">
                                   		<div class="form-group">
                                         <label class="control-label" style="vertical-align:top;">Profile Photo<span class="required_field">*</span> </label>    
                               			<div class="fileinput <?php echo (!empty($u->pic))?"fileinput-exists":"fileinput-new" ?> " data-provides="fileinput">
                                        
                                            <div>
                                        <span class="btn btn-default btn-file">
                                            <span class="fileinput-new btn btn-primary text-uppercase">Select image</span>
                                            <?php if($u->pic): ?>
                                          	  <input id="inputFile" accept="image/*" name="inputFile" type="file" class="form-control"/>
                                          
                                            <?php else: ?>
                                            <input id="inputFile" accept="image/*" name="inputFile" type="file" class="form-control requiresd"/>
                                            <?php endif; ?>
                                        </span>
                                        <div class="fileinput-preview thumbnail" style="max-width: 200px; max-height: 200px;">
                                           	  <?php if($u->pic): ?>
                                                        <?php if((substr($u->pic, 0,5)) == 'https'): ?>
                                                            <img src="<?php echo e($u->pic); ?>" alt="img" class="img-responsive"/>
                                                        <?php else: ?>
                                                            <img src="<?php echo url('/').'/images/users/'.$u->id .'/'. $u->pic; ?>" alt="img" class="img-responsive"/>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                           </div>
                                        <br />
                                        <?php if(!empty($u->pic)): ?>
                                        <a href="#" style="margin-left:90px;" class="btn btn-danger fileinput-exists mb-1 btn btn-danger text-uppercase" data-dismiss="fileinput">Remove</a>
                                         <?php else: ?>
                                        <a href="#" style="margin-left:90px;" class="btn btn-danger fileinput-exists mb-1 btn btn-danger text-uppercase" data-dismiss="fileinput">Remove</a>
                                        
                                         <?php endif; ?> 
                                            </div>
                                      	   
                                            
                                        </div>
                                       
                                    </div> 	
                                    </div>
                                    	
                                </div>
                                 <h4 style="border-bottom:1px dotted #000; margin-left:0px; margin-top:10px; padding-bottom:10px;">Address</h4>
                           <div class="row p-0">
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label class="control-label">Country <span class="required_field">*</span></label>
                                    <select class="form-control required select2" name="country" id="country">
                                       <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($u->country==$k): ?>
                                        <option value="<?php echo e($k); ?>" selected="selected"><?php echo e($v); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                                        <?php endif; ?>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label class="control-label">State <span class="required_field">*</span></label>
                                     <?php echo Form::select('state', $state,$u->state,['class' => 'select2 required form-control', 'id' => 'state']); ?>


                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label class="control-label">City <span class="required_field">*</span></label>
                                     <?php echo Form::select('city', $city,$u->city,['class' => 'select2 required form-control', 'id' => 'city']); ?>

                                 </div>
                              </div>
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label class="control-label">Sub City <span class="required_field">*</span></label>
                                     <?php echo Form::select('sub_city', $sub_city,$u->sub_city,['class' => 'select2 required form-control', 'id' => 'sub_city']); ?>

                                 </div>
                              </div>
                              <div class="col-md-9">
                                 <div class="form-group">
                                    <label class="control-label" for="address">Address <span class="required_field">*</span></label>
                                    <input type="text" class="form-control required" value="<?php echo e($u->address); ?>"  name="address" id="address" placeholder="Address" >
                                 </div>
                              </div>
                              
                              <div class="col-md-3">
                                 <div class="form-group">
                                    <label class="control-label">Zipcode <span class="required_field">*</span></label>
                                    <input type="text" class="form-control required" value="<?php echo e($u->zipcode); ?>"  name="zipcode" id="zipcode" placeholder="Zip Code"  >
                                 </div>
                              </div>
                           </div>
                              
                              <div class="form-group text-center">
                                    <div class=" text-right">
                                        <input type="submit" class="btn btn-primary text-uppercase" value="Submit" name="submit">
                                        <a href="<?php echo e(url('/admin/users')); ?>"  data-toggle="tooltip" title="Cancel"><input type="button" class="btn btn-danger text-uppercase" value="Cancel"></a>
                                    </div>
                                </div>

                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery(".select2").select2();
		jQuery(".datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
		jQuery(document).on("submit","#adduser",function(e){
			
			if($('#adduser').valid()){
				$('#adduser').submit();
				return true;	
			}else{
				return false;		
			}	
		});
       
    });
	
	
function getState(){
var country = $('#country').val();

$("#state").empty();
$("#state").append('<option value="">Select State</option>');
 $("#city").empty();
$("#city").append('<option value="">Select City</option>');

  $("#sub_city").empty();
  $("#sub_city").append('<option value="">Select Sub City</option>');

  
  
                  
if (country !== '') {

    //Populate Sub Category Drop Down
    $.ajax({
        type:"GET",
        dataType: "json",
        url:"<?php echo e(url('/admin/getState')); ?>?country="+country,
        success:function(data){
            if ( data ) {
                
                $.each( data, function( key, value ) {
                    $("#state").append('<option value="'+key+'">'+value+'</option>');
                });
            }
        }
    })
  
}
	
}
$("#country").on('change',function(){
getState();
});
$("#state").on('change',function(){

var state = $('#state').val();
  $("#city").empty();
  $("#city").append('<option value="">Select City</option>');
  
  $("#sub_city").empty();
  $("#sub_city").append('<option value="">Select Sub City</option>');
 
               
if (state !== '') {

    //Populate Sub Category Drop Down
    $.ajax({
        type:"GET",
        dataType: "json",
        url:"<?php echo e(url('/admin/getCity')); ?>?state="+this.value,
        success:function(data){
            if ( data ) {
                
                $.each( data, function( key, value ) {
                    $("#city").append('<option value="'+key+'">'+value+'</option>');
                });
            }
        }
    })
  
}

});

$("#city").on('change',function(){

var city = $('#city').val();
  $("#sub_city").empty();
  $("#sub_city").append('<option value="">Select Sub City</option>');
               
if (city !== '') {

    //Populate Sub Category Drop Down
    $.ajax({
        type:"GET",
        dataType: "json",
        url:"<?php echo e(url('/admin/getSubCity')); ?>?city="+this.value,
        success:function(data){
            if ( data ) {
                
                $.each( data, function( key, value ) {
                    $("#sub_city").append('<option value="'+key+'">'+value+'</option>');
                });
            }
        }
    })
  
}
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\new_xampp\htdocs\yassir-newtheme\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>