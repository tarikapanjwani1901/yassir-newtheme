-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2022 at 11:22 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yassir`
--

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(11) NOT NULL,
  `property_vendor` int(11) DEFAULT NULL,
  `property_for` enum('Sell','Rent') DEFAULT NULL,
  `category` enum('For Builder','For owner') DEFAULT NULL,
  `sub_category` enum('Residential','Commercial','IndustrialParkShades','VacantLandPlotting') DEFAULT NULL,
  `property_type` enum('Apartment And Flat','IndependentHouse','Farmhouse') DEFAULT NULL,
  `commercial_property_type` enum('Office','Retail','Hospitality') DEFAULT NULL,
  `what_kind_of_vacantland` enum('Commercial Land','Agriculture Land','Industrial Land') DEFAULT NULL,
  `project_name` text DEFAULT NULL,
  `what_kind_of_hospitality` enum('Hotel / Resort','Guesthouse / Banquet Hall') DEFAULT NULL,
  `retail_type` enum('Commercial shops','Commercial showrooms') DEFAULT NULL,
  `shop_located_inside` enum('Mall','Commercial Project','Residencial Project') DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `located_inside` enum('IT Park','Business Park') DEFAULT NULL,
  `rera_number` varchar(255) DEFAULT NULL,
  `rera_link` varchar(255) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `sub_city` int(11) DEFAULT NULL,
  `area` int(11) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `area_details` varchar(255) DEFAULT NULL,
  `carpet_area` varchar(255) NOT NULL,
  `property_status` enum('Ready to move','Under Construction') NOT NULL,
  `age_of_property` enum('0-1 Year','1-5 Year','5-10 Year','10+ Year') DEFAULT NULL,
  `possesion_date` date DEFAULT NULL,
  `number_of_washrooms` int(11) DEFAULT NULL,
  `super_builtup_area` varchar(255) DEFAULT NULL,
  `plot_area` varchar(255) DEFAULT NULL,
  `pre_leased` enum('No','Yes') NOT NULL,
  `fire_noc_certified` enum('No','Yes') NOT NULL,
  `number_of_rooms` varchar(255) DEFAULT NULL,
  `number_of_balconies` varchar(255) DEFAULT NULL,
  `furnishing_detail` enum('Un furnished','Semi furnished','Furnished') NOT NULL,
  `furnished_data` text DEFAULT NULL,
  `entrance_width` varchar(255) DEFAULT NULL,
  `ceiling_heights` varchar(255) DEFAULT NULL,
  `number_of_private_washroom` varchar(255) DEFAULT NULL,
  `number_of_shared_washroom` varchar(255) DEFAULT NULL,
  `conference_room` enum('Available','Not Available') NOT NULL,
  `reception_area` enum('Available','Not Available') NOT NULL,
  `facilities` text DEFAULT NULL,
  `fire_safety_measures` text DEFAULT NULL,
  `number_of_floor` varchar(255) DEFAULT NULL,
  `number_of_passenger_lifts` varchar(255) DEFAULT NULL,
  `number_of_service_lift` varchar(255) DEFAULT NULL,
  `number_of_staircases` varchar(255) DEFAULT NULL,
  `number_of_parking_allotted` varchar(255) DEFAULT NULL,
  `parkings` text DEFAULT NULL,
  `suitable_business_type` text DEFAULT NULL,
  `amenities` text DEFAULT NULL,
  `property_features` text DEFAULT NULL,
  `project_features` text DEFAULT NULL,
  `additional_features` text DEFAULT NULL,
  `other_features` text DEFAULT NULL,
  ` location_advantages` text DEFAULT NULL,
  `suggestions` text DEFAULT NULL,
  `ProjectGallery` text DEFAULT NULL,
  `FloorplanGallery` text DEFAULT NULL,
  `ProjectstatusGallery` text DEFAULT NULL,
  `video_toor` varchar(255) DEFAULT NULL,
  `pdf_brochure` varchar(255) DEFAULT NULL,
  `sample_house_video` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `property_vendor`, `property_for`, `category`, `sub_category`, `property_type`, `commercial_property_type`, `what_kind_of_vacantland`, `project_name`, `what_kind_of_hospitality`, `retail_type`, `shop_located_inside`, `locality`, `located_inside`, `rera_number`, `rera_link`, `country`, `state`, `city`, `sub_city`, `area`, `zip_code`, `address`, `area_details`, `carpet_area`, `property_status`, `age_of_property`, `possesion_date`, `number_of_washrooms`, `super_builtup_area`, `plot_area`, `pre_leased`, `fire_noc_certified`, `number_of_rooms`, `number_of_balconies`, `furnishing_detail`, `furnished_data`, `entrance_width`, `ceiling_heights`, `number_of_private_washroom`, `number_of_shared_washroom`, `conference_room`, `reception_area`, `facilities`, `fire_safety_measures`, `number_of_floor`, `number_of_passenger_lifts`, `number_of_service_lift`, `number_of_staircases`, `number_of_parking_allotted`, `parkings`, `suitable_business_type`, `amenities`, `property_features`, `project_features`, `additional_features`, `other_features`, ` location_advantages`, `suggestions`, `ProjectGallery`, `FloorplanGallery`, `ProjectstatusGallery`, `video_toor`, `pdf_brochure`, `sample_house_video`, `created_at`, `updated_at`) VALUES
(1, 76, 'Sell', 'For Builder', 'Commercial', NULL, 'Retail', '', 'ABCNew', '', 'Commercial showrooms', 'Commercial Project', '', '', '', '', 101, 12, 779, 1, 4, '10002', 'Vikram Park', '', '100.22', '', '', '2002-02-09', 0, '333.2', '', 'Yes', 'Yes', '', '', '', '', '9999', '3333', '2', '3', 'Not Available', 'Not Available', 'Furnishing, Central air conditioning', 'Fire Safety Extinguisher, Sprinklers', '8', '2', '3', '4', '4', 'Private parking in basement, Private parking outside, Public Parking', '', '2, 3', 'Gas Pipeline, Central air conditioning, Natural light, Airy rooms, Spacious, Ac Points, Electric Charging Points', 'kkkk', 'kkkk', 'Gated Society, Corner side property, Roade facing property', NULL, 'sss', NULL, NULL, NULL, NULL, NULL, NULL, '2022-07-23 07:04:42', '2022-07-23 07:12:45'),
(2, 76, 'Sell', 'For Builder', 'Commercial', NULL, 'Retail', '', 'ABCNew', '', 'Commercial showrooms', 'Commercial Project', '', '', '', '', 101, 12, 779, 1, 4, '10002', 'Vikram Park', '', '100.22', '', '', '2002-02-09', 0, '333.2', '', 'Yes', 'Yes', '', '', '', '', '9999', '3333', '2', '3', 'Not Available', 'Not Available', 'Furnishing, Central air conditioning', 'Fire Safety Extinguisher, Sprinklers', '8', '2', '3', '4', '4', 'Private parking in basement, Private parking outside, Public Parking', '', '2, 3', 'Gas Pipeline, Central air conditioning, Natural light, Airy rooms, Spacious, Ac Points, Electric Charging Points', 'kkkk', 'kkkk', 'Gated Society, Corner side property, Roade facing property', NULL, 'sss', NULL, NULL, NULL, NULL, NULL, NULL, '2022-07-23 07:04:42', '2022-07-23 07:12:45'),
(3, 76, 'Sell', 'For Builder', 'Commercial', NULL, 'Retail', '', 'ABCNew', '', 'Commercial showrooms', 'Commercial Project', '', '', '', '', 101, 12, 779, 1, 4, '10002', 'Vikram Park', '', '100.22', '', '', '2002-02-09', 0, '333.2', '', 'Yes', 'Yes', '', '', '', '', '9999', '3333', '2', '3', 'Not Available', 'Not Available', 'Furnishing, Central air conditioning', 'Fire Safety Extinguisher, Sprinklers', '8', '2', '3', '4', '4', 'Private parking in basement, Private parking outside, Public Parking', '', '2, 3', 'Gas Pipeline, Central air conditioning, Natural light, Airy rooms, Spacious, Ac Points, Electric Charging Points', 'kkkk', 'kkkk', 'Gated Society, Corner side property, Roade facing property', NULL, 'sss', NULL, NULL, NULL, NULL, NULL, NULL, '2022-07-23 07:04:42', '2022-07-23 07:12:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
