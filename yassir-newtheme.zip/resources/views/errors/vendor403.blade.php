@extends('layouts.vendor.app')
@section('content')
    <div class="col-lg-10 col-md-10 admin-background permission-msg">
        <h1>You don't have permission</h1>   
    </div>
@endsection 