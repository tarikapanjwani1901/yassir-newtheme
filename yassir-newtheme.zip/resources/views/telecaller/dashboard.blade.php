@extends('layouts.telecaller.app')
@section('content')
<h2>Hello !</h2>
@endsection