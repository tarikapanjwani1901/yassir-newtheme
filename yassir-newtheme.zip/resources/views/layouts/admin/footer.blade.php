<!--**********************************
    Footer start
***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Silverxis</a> {{ date('Y') }}</p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->