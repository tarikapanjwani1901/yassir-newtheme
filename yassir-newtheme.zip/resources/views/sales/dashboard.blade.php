@extends('layouts.marketing.app')
@section('content')
<h2>Hello !</h2>
@endsection